# SSH connection
HOST_NAME = "localhost"
USER = "user"
KEY_PATH = "path/to/key"
LOG_PATH = "debug.txt"

# Instruction file
FILE_PATH = "aivi2_cfg04_board_UNKNOWN.trc"