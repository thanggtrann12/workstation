// Trie imp
// Author: DHHD - did4hc

class TrieNode {
  constructor() {
    this.value = null;
    this.parent = null;
    this.children = {}; // Hash map to improve speed
    this.endWord = false;
  }

  getWord() {
    let node = this;
    let output = [];
    while (node.value) {
      output.push(node.value);
      node = node.parent;
    }
    output.reverse();
    return output.join('');
  }
}

class Trie {
  constructor({ caseSensitive = false }) {
    this.root = new TrieNode();
    this.caseS = caseSensitive;
  }

  insert(word) {
    let node = this.root;

    for (let ch of word) {
      let chLkup = ch;

      if (this.caseS === false) {
        chLkup = chLkup.toLowerCase();
      }

      if (node.children[chLkup] === undefined) {
        node.children[chLkup] = new TrieNode();
        node.children[chLkup].value = ch;
        node.children[chLkup].parent = node;
      }
      node = node.children[chLkup];
    }
    node.endWord = true;
  }

  contain(word) {
    let node = this.root;

    if (this.caseS === false) {
      word = word.toLowerCase();
    }

    for (let ch of word) {
      if (node.children[ch]) {
        node = node.children[ch];
      } else {
        return false;
      }
    }
    return node.endWord;
  }

  find(prefix) {
    let node = this.root;
    let output = [];

    if (this.caseS === false) {
      prefix = prefix.toLowerCase();
    }

    // prefix forward
    for (let ch of prefix) {
      if (node.children[ch]) {
        node = node.children[ch];
      } else {
        return output;
      }
    }

    this.findAllWords(node, output);
    return output;
  }

  findAllWords(node, result) {
    if (node.endWord) {
      result.push(node.getWord());
    }

    for (let ch in node.children) {
      this.findAllWords(node.children[ch], result);
    }
  }
}
