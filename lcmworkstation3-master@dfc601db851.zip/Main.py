import os
import subprocess

from ToellnerDriver import ToellnerDriver
from flask import Flask, render_template, request, redirect, send_file
from flask_socketio import SocketIO, send, emit
from serial import Serial
from threading import Thread
from time import sleep
from TTFisClient import TTFisClient
from werkzeug.utils import secure_filename
import config
import json
from InstructionSetProcess import process_instruction_file

SETTING_FILE_NAME = "setting.json"
OUTPUT_TRACE_FILE_PATH = "output/output.pro"

_app = Flask(__name__)
_app.config["SECRET_KEY"] = "LCM Workstation"
_socketio = SocketIO(_app)

_lockUser = ""
_updateStatus = ""
_setting = None
_ttfisClient = None
_appConnection = None
_toellner = None

def _BroadCastGeneralInfoPeriodly():
    while (True):
        _BroadCastGeneralInfo()
        sleep(1)

def _BroadCastGeneralInfo():
    global _socketio
    global _toellner

    if (None != _toellner):
        voltageValue = str(float(_toellner.GetVoltage().decode()))
        currentValue = str(float(_toellner.GetCurrent().decode()))
        _socketio.emit("powerValue", {"current":currentValue, "voltage":voltageValue}, broadcast=True)


def _UpdateTraceContent(content_):
    _socketio.send(content_, broadcast=True)

def _Sleep():
    global _setting

    scriptSetting = _setting["script"]
    subprocess.run([scriptSetting["sleepCommand"]], stdout=subprocess.PIPE)

def _Reset():
    global _setting

    scriptSetting = _setting["script"]
    subprocess.run([scriptSetting["resetCommand"]], stdout=subprocess.PIPE)

def _Flash():
    global _setting
    global _ttfisClient
    
    scriptSetting = _setting["script"]
    binarySetting = _setting["binary"]
    deviceName = _setting["device"]

    subprocess.run([scriptSetting["flashCommand"]], stdout=subprocess.PIPE)

    _ttfisClient.Disconnect(deviceName)
    _ttfisClient.Connect(deviceName)
    _ttfisClient.Restart()
    _ttfisClient.LoadTRCFiles([(binarySetting["path"] + "/" + binarySetting["traceFileName"])])

@_socketio.on("connect")
def ConnectSocket():
    global _lockUser
    global _updateStatus

    emit("lockStatus", {"data":_lockUser}, broadcast=True)
    emit("updateStatus", {"data":_updateStatus}, broadcast=True)

@_app.route("/", methods=["GET"])
def Index():
    return render_template("index.html")

@_app.route("/SetPower/<state_>/", methods=["GET"])
def SetPower(state_):
    global _toellner
    resp = {}

    if (None == _toellner):
        resp["result"] = "This feature is not support for your workstation"
        return resp

    if ("off" == state_):
        _toellner.SetVoltage(0)
    else:
        global _setting
        _toellner.SetVoltage(_setting["voltage"]["normal"])


    resp["result"] = ""
    return resp

@_app.route("/SetVoltage/", methods=["POST"])
def SetVoltage():
    global _toellner
    resp = {}

    if (None == _toellner):
        resp["result"] = "This feature is not support for your workstation"
        return resp

    global _setting
    try:
        voltageValue = float(request.data.decode())
        voltageValue = int(voltageValue)
        maxVoltageValue = _setting["voltage"]["max"]
        if ((0 <= voltageValue) and (voltageValue <= maxVoltageValue)):
            _toellner.SetVoltage(voltageValue)
        else:
            resp["result"] = "The voltage value must be in range 0-%d(V)" %(maxVoltageValue)
            return resp
    except Exception as e:
        resp["result"] = "Invalid value"
        return resp

    resp["result"] = "Set voltage successfully"
    return resp

@_app.route("/Lock/", methods=["POST"])
def Lock():
    global _socketio
    global _lockUser
    resp = {}
    _lockUser = request.data.decode()
    _socketio.emit("lockStatus", {"data":_lockUser}, broadcast=True)
    return resp

@_app.route("/Unlock/", methods=["GET"])
def Unlock():
    global _socketio
    global _lockUser

    resp = {}
    _lockUser = ""
    _socketio.emit("lockStatus", {"data":_lockUser}, broadcast=True)
    return resp

@_app.route("/Sleep/", methods=["GET"])
def Sleep():
    global _updateStatus
    global _socketio

    _updateStatus = "Sleeping..."
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
    _Sleep()

    _updateStatus = "Ready"
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)

@_app.route("/Reset/", methods=["GET"])
def Reset():
    global _updateStatus
    global _socketio

    _updateStatus = "Reseting..."
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
    _Reset()

    _updateStatus = "Ready"
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)

@_app.route("/Upload/", methods=["POST"])
def Upload():
    global _updateStatus
    resp = {}

    if ("Ready" != _updateStatus):
        return resp

    global _socketio
    global _setting

    _updateStatus = "Uploading..."
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
    data = request.files
    binarySetting = _setting["binary"]

    binaryFile = data["binaryFile"]
    binaryFilePath = ""
    if (binaryFile.filename == binarySetting["binaryFileName"]):
        binaryFilePath = (binarySetting["path"] + "/" + binarySetting["binaryFileName"])
    else:
        resp["error"] = "Invalid binary file"
        _updateStatus = "Ready"
        _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
        return resp

    traceFile =  data["traceFile"]
    traceFilePath = ""
    if (traceFile.filename == binarySetting["traceFileName"]):
        traceFilePath = (binarySetting["path"] + "/" + binarySetting["traceFileName"])
    else:
        resp["error"] = "Invalid trace file"
        _updateStatus = "Ready"
        _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
        return resp

    binaryFile.save(binarySetting["path"] + "/" + binarySetting["binaryFileName"])
    traceFile.save(binarySetting["path"] + "/" + binarySetting["traceFileName"])

    _updateStatus = "Flashing..."
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
    _Flash()

    _updateStatus = "Ready"
    _socketio.emit("updateStatus", {"data":_updateStatus}, broadcast=True)
    return resp

@_app.route("/RunCommand/", methods=["POST"])
def RunCommand():
    global _ttfisClient

    resp = {}
    cmdStr = request.data.decode()
    _UpdateTraceContent(cmdStr)
    _ttfisClient.Cmd(cmdStr)
    return resp

@_app.route("/GetCommandSet/", methods=["GET"])
def GetCommandSet():
    global _setting
    binarySetting = _setting["binary"]
    traceFilePath = (binarySetting["path"] + "/" + binarySetting["traceFileName"])
    return process_instruction_file(traceFilePath)

@_socketio.on("appInput")
def ReceiveAppInput(data_):
    global _appConnection
    _appConnection.write(data_["input"].encode())

def _ReadAppData():
    global _appConnection
    global _socketio

    while (True):
        data = _appConnection.read(128)
        if (b"" != data):
            try:
                _socketio.emit("appContent", {"data":data.decode()}, broadcast=True)
            except Exception as e:
                pass

if __name__ == "__main__":
    _ttfisClient = TTFisClient()
    _ttfisClient.registerUpdateTraceCallback(_UpdateTraceContent)

    settingFile = open(SETTING_FILE_NAME, "r")
    import json
    _setting = json.loads(settingFile.read())

    _ttfisClient.Connect(_setting["device"])

    binarySetting = _setting["binary"]
    traceFilePath = (binarySetting["path"] + "/" + binarySetting["traceFileName"])
    if os.path.exists(traceFilePath):
        _ttfisClient.LoadTRCFiles([traceFilePath])

    _appConnection = Serial(port=_setting["appSerialPort"], baudrate=115200, timeout=0.01)
    sleep(1)
    Thread(target=_ReadAppData, args=()).start()

    powerSupplySetting = _setting["powerSupply"]
    serialPort = powerSupplySetting["serialPort"]
    if ("" != serialPort):
        _toellner = ToellnerDriver(port_=serialPort, channel_=powerSupplySetting["channel"])

    if (None != _toellner):
        Thread(target=_BroadCastGeneralInfoPeriodly, args=()).start()

    _updateStatus = "Ready"

    _socketio.run(_app, host="0.0.0.0", port=5000)

    _ttfisClient.Quit()
    del _ttfisClient
